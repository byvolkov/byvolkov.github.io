Скачиваем rest.php
http://www.bitrixsoft.com/download/scripts/rest.php

Информация по параметрам полей
http://dev.1c-bitrix.ru/community/blogs/chaos/crm-sozdanie-lidov-iz-drugikh-servisov.php
